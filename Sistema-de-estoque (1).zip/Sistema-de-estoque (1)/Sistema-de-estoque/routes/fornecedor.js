const express = require('express');
const routes = express.Router();
const db = require('../db/connect');


// LISTAR TODOS OS FORNECEDORES
routes.get('/', (req, res) => {

    db.query('SELECT * FROM fornecedor ORDER BY id')
        .then((resultado) => {

            return res.status(200).json(resultado.rows);

        })
        .catch((error) => {

            return res.status(500).json({
                mensagem: error.message
            });

        });

});


// BUSCAR FORNECEDOR POR ID
routes.get('/:id', (req, res) => {

    const { id } = req.params;

    db.query(
        'SELECT * FROM fornecedor WHERE id = $1',
        [id]
    )
    .then((resultado) => {

        if (resultado.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Fornecedor não encontrado.'
            });
        }

        return res.status(200).json(resultado.rows[0]);

    })
    .catch((error) => {

        return res.status(500).json({
            mensagem: error.message
        });

    });

});


// CADASTRAR FORNECEDOR
routes.post('/', (req, res) => {

    const {
        nome,
        email,
        telefone,
        endereco,
        cidade,
        uf,
        produtos
    } = req.body;

    if (!nome) {
        return res.status(400).json({
            mensagem: 'O nome é obrigatório.'
        });
    }

    db.query(
        `INSERT INTO fornecedor
        (nome, email, telefone, endereco, cidade, uf, produtos)
        VALUES ($1, $2, $3, $4, $5, $6, $7)`,
        [nome, email, telefone, endereco, cidade, uf, produtos]
    )
    .then(() => {

        return res.status(201).json({
            mensagem: 'Fornecedor cadastrado com sucesso.'
        });

    })
    .catch((error) => {

        return res.status(500).json({
            mensagem: error.message
        });

    });

});


// ATUALIZAR FORNECEDOR
routes.put('/:id', (req, res) => {

    const { id } = req.params;

    const {
        nome,
        email,
        telefone,
        endereco,
        cidade,
        uf,
        produtos
    } = req.body;

    if (!nome) {
        return res.status(400).json({
            mensagem: 'O nome é obrigatório.'
        });
    }

    db.query(
        `UPDATE fornecedor
        SET nome = $1,
            email = $2,
            telefone = $3,
            endereco = $4,
            cidade = $5,
            uf = $6,
            produtos = $7
        WHERE id = $8`,
        [nome, email, telefone, endereco, cidade, uf, produtos, id]
    )
    .then((resultado) => {

        if (resultado.rowCount === 0) {
            return res.status(404).json({
                mensagem: 'Fornecedor não encontrado.'
            });
        }

        return res.status(200).json({
            mensagem: 'Fornecedor atualizado com sucesso.'
        });

    })
    .catch((error) => {

        return res.status(500).json({
            mensagem: error.message
        });

    });

});


// EXCLUIR FORNECEDOR
routes.delete('/:id', (req, res) => {

    const { id } = req.params;

    db.query(
        'DELETE FROM fornecedor WHERE id = $1',
        [id]
    )
    .then((resultado) => {

        if (resultado.rowCount === 0) {
            return res.status(404).json({
                mensagem: 'Fornecedor não encontrado.'
            });
        }

        return res.status(200).json({
            mensagem: 'Fornecedor removido com sucesso.'
        });

    })
    .catch((error) => {

        return res.status(500).json({
            mensagem: error.message
        });

    });

});


module.exports = routes;