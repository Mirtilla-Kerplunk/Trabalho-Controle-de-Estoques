const express = require('express');
const router = express.Router();
const pool = require('../db/connect');

// Rota de login
router.post('/', async (req, res) => {
    try {
        const { usuario, senha } = req.body;

        // Validação básica dos campos
        if (!usuario || !senha) {
            return res.status(400).json({
                sucesso: false,
                erro: 'Preencha usuário e senha'
            });
        }

        // Consulta no banco
        const resultado = await pool.query(
            'SELECT id, usuario, nome_completo, perfil FROM usuarios WHERE usuario = $1 AND senha = $2',
            [usuario, senha]
        );

        if (resultado.rows.length === 0) {
            return res.status(401).json({
                sucesso: false,
                erro: 'Usuário ou senha incorretos'
            });
        }

        // Se encontrou, retorna os dados
        res.json({
            sucesso: true,
            mensagem: 'Login realizado com sucesso',
            nome: resultado.rows[0].nome_completo,
            perfil: resultado.rows[0].perfil,
            usuario: resultado.rows[0]
        });

    } catch (erro) {
        console.error('Erro no login:', erro.message);
        res.status(500).json({
            sucesso: false,
            erro: 'Erro interno no servidor'
        });
    }
});

module.exports = router;