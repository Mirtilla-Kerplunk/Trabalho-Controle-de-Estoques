require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST,
  port: parseInt(process.env.DB_PORT, 10),
  user: process.env.DB_USER,
  password: String(process.env.DB_PASSWORD || ''),
  database: process.env.DB_NAME
});

pool.connect()
  .then(async () => {

    await pool.query(`
      CREATE TABLE IF NOT EXISTS produtos (
        id SERIAL PRIMARY KEY,
        codigo VARCHAR(50),
        nome VARCHAR(100) NOT NULL,
        categoria VARCHAR(50),
        preco NUMERIC(10,2) DEFAULT 0,
        quantidade INTEGER DEFAULT 0,
        validade DATE
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS movimentacoes (
        id SERIAL PRIMARY KEY,
        produto_id INTEGER REFERENCES produtos(id) ON DELETE CASCADE,
        tipo VARCHAR(20) NOT NULL,
        quantidade INTEGER NOT NULL,
        fornecedor VARCHAR(100),
        motivo VARCHAR(255),
        responsavel VARCHAR(100),
        data_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id SERIAL PRIMARY KEY,
        usuario VARCHAR(50) UNIQUE NOT NULL,
        senha VARCHAR(100) NOT NULL,
        nome_completo VARCHAR(100) NOT NULL,
        perfil VARCHAR(50) DEFAULT 'estoquista'
      )
    `);

    await pool.query(`
      INSERT INTO usuarios (usuario, senha, nome_completo, perfil)
      VALUES ('admin', '123456', 'Administrador', 'admin')
      ON CONFLICT (usuario) DO NOTHING
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS cliente (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        telefone VARCHAR(20),
        endereco VARCHAR(200),
        cidade VARCHAR(100),
        uf VARCHAR(2)
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS fornecedor (
        id SERIAL PRIMARY KEY,
        nome VARCHAR(100) NOT NULL,
        email VARCHAR(100),
        telefone VARCHAR(20),
        endereco VARCHAR(200),
        cidade VARCHAR(100),
        uf VARCHAR(2),
        produtos VARCHAR(255)
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS entrada (
        id SERIAL PRIMARY KEY,
        produto_id INTEGER REFERENCES produtos(id) ON DELETE CASCADE,
        quantidade INTEGER NOT NULL,
        data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await pool.query(`
      CREATE TABLE IF NOT EXISTS saida (
        id SERIAL PRIMARY KEY,
        produto_id INTEGER REFERENCES produtos(id) ON DELETE CASCADE,
        cliente_id INTEGER REFERENCES cliente(id) ON DELETE SET NULL,
        quantidade INTEGER NOT NULL,
        data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
  })
  .catch(err => console.error('❌ Erro de conexão:', err.message));

module.exports = pool;