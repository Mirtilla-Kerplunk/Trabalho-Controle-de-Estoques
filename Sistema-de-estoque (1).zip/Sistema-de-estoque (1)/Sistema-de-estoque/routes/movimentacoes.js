// routes/movimentacoes.js
const express = require('express');
const router = express.Router();
const pool = require('../db/connect');

// Listar todo o histórico
router.get('/', async (req, res) => {
  try {
    const resultado = await pool.query(`
      SELECT m.*, p.nome AS produto_nome
      FROM movimentacoes m
      JOIN produtos p ON m.produto_id = p.id
      ORDER BY m.data_hora DESC
    `);
    res.json(resultado.rows);
  } catch (erro) {
    res.status(500).json({ sucesso: false, erro: erro.message });
  }
});

// Registrar ENTRADA
router.post('/entrada', async (req, res) => {
  try {
    const { produto_id, quantidade, fornecedor, validade, responsavel } = req.body;

    // Iniciar transação para garantir que tudo ou nada acontece
    await pool.query('BEGIN');

    // Atualizar quantidade do produto
    await pool.query(
      'UPDATE produtos SET quantidade = quantidade + $1, validade = $2 WHERE id = $3',
      [quantidade, validade, produto_id]
    );

    // Salvar registro da movimentação
    await pool.query(
      `INSERT INTO movimentacoes 
        (produto_id, tipo, quantidade, fornecedor, motivo, responsavel, data_hora)
       VALUES ($1, 'ENTRADA', $2, $3, null, $4, NOW())`,
      [produto_id, quantidade, fornecedor, responsavel]
    );

    await pool.query('COMMIT');
    res.json({ sucesso: true, mensagem: 'Entrada registrada!' });

  } catch (erro) {
    await pool.query('ROLLBACK');
    res.status(400).json({ sucesso: false, erro: erro.message });
  }
});

// Registrar SAÍDA
router.post('/saida', async (req, res) => {
  try {
    const { produto_id, quantidade, motivo, responsavel } = req.body;

    await pool.query('BEGIN');

    // Verificar se tem estoque suficiente
    const verificar = await pool.query(
      'SELECT quantidade FROM produtos WHERE id = $1',
      [produto_id]
    );

    if (verificar.rows[0].quantidade < quantidade) {
      await pool.query('ROLLBACK');
      return res.status(400).json({ sucesso: false, mensagem: 'Estoque insuficiente!' });
    }

    // Atualizar quantidade
    await pool.query(
      'UPDATE produtos SET quantidade = quantidade - $1 WHERE id = $2',
      [quantidade, produto_id]
    );

    // Salvar registro
    await pool.query(
      `INSERT INTO movimentacoes 
        (produto_id, tipo, quantidade, fornecedor, motivo, responsavel, data_hora)
       VALUES ($1, 'SAÍDA', $2, null, $3, $4, NOW())`,
      [produto_id, quantidade, motivo, responsavel]
    );

    await pool.query('COMMIT');
    res.json({ sucesso: true, mensagem: 'Saída registrada!' });

  } catch (erro) {
    await pool.query('ROLLBACK');
    res.status(400).json({ sucesso: false, erro: erro.message });
  }
});

module.exports = router;