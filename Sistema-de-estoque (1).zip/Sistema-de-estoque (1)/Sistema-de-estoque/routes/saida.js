const express = require('express');
const routes = express.Router();
const db = require('../db/connect');

// Registrar saída de produto
routes.post('/', async (req, res) => {

    try {

        const { produto_id, cliente_id, quantidade } = req.body;

        // Verificar se todos os campos foram enviados
        if (!produto_id || !cliente_id || !quantidade) {
            return res.status(400).json({
                mensagem: 'Produto, cliente e quantidade são obrigatórios.'
            });
        }

        // Verificar se o produto existe
        const produto = await db.query(
            'SELECT quantidade FROM produto WHERE id = $1',
            [produto_id]
        );

        if (produto.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Produto não encontrado.'
            });
        }

        // Verificar estoque disponível
        const estoqueAtual = produto.rows[0].quantidade;

        if (estoqueAtual < quantidade) {
            return res.status(400).json({
                mensagem: 'Estoque insuficiente.'
            });
        }

        // Registrar a saída
        await db.query(
            `INSERT INTO saida
            (produto_id, cliente_id, quantidade)
            VALUES ($1, $2, $3)`,
            [produto_id, cliente_id, quantidade]
        );

        // Atualizar o estoque
        await db.query(
            `UPDATE produto
             SET quantidade = quantidade - $1
             WHERE id = $2`,
            [quantidade, produto_id]
        );

        return res.status(201).json({
            mensagem: 'Saída registrada com sucesso.'
        });

    } catch (error) {

        return res.status(500).json({
            mensagem: error.message
        });

    }

});

module.exports = routes;