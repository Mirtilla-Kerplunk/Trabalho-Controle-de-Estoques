const express = require('express');
require('dotenv').config();

// Conexão com banco
const pool = require('./db/connect');

// Rotas
const produtosRoutes = require('./routes/produto');
const movimentacoesRoutes = require('./routes/movimentacoes');
const loginRoutes = require('./routes/login');
const clienteRoutes = require('./routes/cliente');
const fornecedorRoutes = require('./routes/fornecedor');
const entradaRoutes = require('./routes/entrada');
const saidaRoutes = require('./routes/saida');

const app = express();

// Middlewares essenciais
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Servir arquivos estáticos
app.use(express.static('paginas'));
app.use('/css', express.static('css'));

// Usar rotas da API
app.use('/api/produtos', produtosRoutes);
app.use('/api/movimentacoes', movimentacoesRoutes);
app.use('/api/login', loginRoutes);
app.use('/api/clientes', clienteRoutes);
app.use('/api/fornecedores', fornecedorRoutes);
app.use('/api/entradas', entradaRoutes);
app.use('/api/saidas', saidaRoutes);
app.use('/api/entrada', entradaRoutes);
app.use('/api/saida', saidaRoutes);

app.get('/', (req, res) => {
    res.sendFile('paginas/login.html', { root: '.' });
});

app.get('/estoque', (req, res) => {
    res.sendFile('paginas/estoque-completo.html', { root: '.' });
});

app.get('/estoque-completo.html', (req, res) => {
    res.sendFile('paginas/estoque-completo.html', { root:'.' });
});

// Iniciar servidor
const hostname = process.env.APP_HOST || '127.0.0.1';
const port = process.env.APP_PORT || 3000;

app.listen(port, hostname, () => {
    console.log(`Servidor rodando em http://${hostname}:${port}`);
});