//Importação dos módulos utilizados no projeto
//Express
const express = require('express');
const path = require('path');
//Criar a instância do aplicativo express
const app = express();
//Dotenv
//Carregar as variáveis de ambiente definidas no arquivo .env
require('dotenv').config();

//Configuração do IP e da PORTA do servidor
const hostname = process.env.APP_HOST || '127.0.0.1';
const port = process.env.APP_PORT || 3000;

// Servir arquivos estáticos da pasta de páginas HTML
app.use(express.static(path.join(__dirname, 'paginas')));

//importando as informações das rotas cliente
const clienteRotas = require('./routes/cliente');
//importando as informações das rotas produto
const produtoRotas = require('./routes/produto');
//importando as informações das rotas entrada
const entradaRotas = require('./routes/entrada');
//importando as informações das rotas login
const loginRotas = require('./routes/login');
//importando as informações das rotas saida
const saidaRotas = require('./routes/saida');
//importando as informações das rotas produto
const fornecedorRotas = require('./routes/fornecedor');

//Definição de rota raiz "/"
//Configuração do servidor
app.get('/', (req, res) => {
    return res.sendFile(path.join(__dirname, 'paginas', 'login.html'));
});

app.get('/estoque', (req, res) => {
    return res.sendFile(path.join(__dirname, 'paginas', 'estoque-completo (1).html'));
});

//Indica que o servidor irá responder com dados Json
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//Expor as rotas do servidor
app.use('/cliente', clienteRotas);
app.use('/produto', produtoRotas);
app.use('/entrada', entradaRotas);
app.use('/login', loginRotas);
app.use('/saida', saidaRotas);
app.use('/fornecedor', fornecedorRotas);

//Inicio do servidor
app.listen(port, hostname, async () =>{
    console.log(`Servidor rodando em http://${hostname}:${port}/`);
});
