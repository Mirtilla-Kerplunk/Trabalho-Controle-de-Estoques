const express = require('express');
const routes = express.Router();
const db = require('../db/connect');

// Listar todas as entradas
routes.get('/', async (req, res) => {
    try {
        const sql = `
            SELECT *
            FROM entrada
            ORDER BY data DESC
        `;

        const result = await db.query(sql);

        return res.status(200).json(result.rows);

    } catch (error) {
        return res.status(500).json({
            mensagem: error.message
        });
    }
});

// Buscar entrada por ID
routes.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;

        const sql = `
            SELECT *
            FROM entrada
            WHERE id = $1
        `;

        const result = await db.query(sql, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Entrada não encontrada'
            });
        }

        return res.status(200).json(result.rows[0]);

    } catch (error) {
        return res.status(500).json({
            mensagem: error.message
        });
    }
});

// Registrar entrada
routes.post('/', async (req, res) => {

    try {

        const { produto_id, quantidade } = req.body;

        if (!produto_id || !quantidade) {
            return res.status(400).json({
                mensagem: 'Produto e quantidade são obrigatórios'
            });
        }

        // Registrar entrada
        const sqlEntrada = `
            INSERT INTO entrada
            (produto_id, quantidade)
            VALUES
            ($1, $2)
        `;

        await db.query(sqlEntrada, [produto_id, quantidade]);

        // Atualizar estoque
        const sqlProduto = `
            UPDATE produto
            SET quantidade = quantidade + $1
            WHERE id = $2
        `;

        await db.query(sqlProduto, [quantidade, produto_id]);

        return res.status(201).json({
            mensagem: 'Entrada registrada com sucesso'
        });

    } catch (error) {

        return res.status(500).json({
            mensagem: error.message
        });

    }

});
// Excluir entrada
routes.delete('/:id', async (req, res) => {
    try {

        const { id } = req.params;

        const sql = `
            DELETE FROM entrada
            WHERE id = $1
            RETURNING *
        `;

        const result = await db.query(sql, [id]);

        if (result.rows.length === 0) {
            return res.status(404).json({
                mensagem: 'Entrada não encontrada'
            });
        }

        return res.status(200).json({
            mensagem: 'Entrada removida com sucesso'
        });

    } catch (error) {
        return res.status(500).json({
            mensagem: error.message
        });
    }
});

module.exports = routes;