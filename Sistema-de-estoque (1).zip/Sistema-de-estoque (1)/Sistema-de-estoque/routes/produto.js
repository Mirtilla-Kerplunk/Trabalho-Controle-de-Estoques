const express = require('express');
const router = express.Router();
const pool = require('../db/connect');

// Listar todos
router.get('/', async (req, res) => {
  try {
    const resultado = await pool.query('SELECT * FROM produtos ORDER BY nome');
    res.json(resultado.rows);
  } catch (erro) {
    res.status(500).json({ erro: erro.message });
  }
});

// Buscar um
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const resultado = await pool.query('SELECT * FROM produtos WHERE id = $1', [id]);
    if (resultado.rows.length === 0) return res.status(404).json({ mensagem: 'Não encontrado' });
    res.json(resultado.rows[0]);
  } catch (erro) {
    res.status(500).json({ erro: erro.message });
  }
});

// Criar (POST usado no Postman)
router.post('/', async (req, res) => {
  try {
    const body = req.body || {};
    const payload = {
      ...body,
      ...(req.query || {})
    };
    const codigo = payload.codigo || payload.cod || payload.idProduto || payload['codigo'] || null;
    const nome = payload.nome || payload.name || payload.produto || payload['nome'] || null;
    const categoria = payload.categoria || payload.category || 'Sem categoria';
    const preco = payload.preco || payload.price || 0;
    const quantidade = payload.quantidade || payload.qty || payload.quantity || 0;
    const validade = payload.validade || payload.validadeProduto || null;

    if (!nome || !codigo) {
      return res.status(400).json({ sucesso: false, erro: 'Nome e código são obrigatórios.' });
    }

    const query = `
      INSERT INTO produtos (codigo, nome, categoria, preco, quantidade, validade)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `;
    const valores = [codigo, nome, categoria, Number(preco) || 0, Number(quantidade) || 0, validade || null];
    const resultado = await pool.query(query, valores);

    return res.status(201).json({ sucesso: true, dados: resultado.rows[0], mensagem: 'Produto cadastrado com sucesso.' });
  } catch (erro) {
    console.error('Erro ao criar produto:', erro.message);
    return res.status(400).json({ sucesso: false, erro: erro.message });
  }
});

// Atualizar
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { codigo, nome, categoria, preco, quantidade, validade } = req.body;
    const query = `
      UPDATE produtos
      SET codigo = $1, nome = $2, categoria = $3, preco = $4, quantidade = $5, validade = $6
      WHERE id = $7
      RETURNING *
    `;
    const valores = [codigo, nome, categoria, preco, quantidade, validade, id];
    const resultado = await pool.query(query, valores);
    res.json({ sucesso: true, dados: resultado.rows[0] });
  } catch (erro) {
    res.status(400).json({ sucesso: false, erro: erro.message });
  }
});

// Excluir
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await pool.query('DELETE FROM produtos WHERE id = $1', [id]);
    res.json({ sucesso: true, mensagem: 'Removido com sucesso' });
  } catch (erro) {
    res.status(400).json({ sucesso: false, erro: erro.message });
  }
});

module.exports = router;