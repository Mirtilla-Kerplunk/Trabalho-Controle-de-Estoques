const { Router } = require("express");

const router = Router();

// Login
router.post('/')

// Validar token (opcional)
router.get('validar')

module.exports = router;