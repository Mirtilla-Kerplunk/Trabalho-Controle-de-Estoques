// Login
router.post('/');

// Validar token (opcional)
router.get('/validar');