-- Criação da tabela produto
CREATE TABLE IF NOT EXISTS produto (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    marca VARCHAR(100),
    preco DECIMAL(8,2),
    peso DECIMAL(8,2),
    quantidade INTEGER DEFAULT 0
);
CREATE TABLE cliente (
    id serial PRIMARY KEY,
    nome varchar(100),
    email varchar(100),
    telefone varchar(11),
    endereco varchar(255),
    cidade varchar(100),
    uf varchar(2)
);
CREATE TABLE fornecedor (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefone VARCHAR(11),
    endereco VARCHAR(255),
    cidade VARCHAR(100),
    uf VARCHAR(2),
    produtos TEXT
);
CREATE TABLE login (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    senha VARCHAR(100) NOT NULL
);
CREATE TABLE entrada (
    id SERIAL PRIMARY KEY,
    produto_id INTEGER REFERENCES produto(id),
    quantidade INTEGER NOT NULL,
    fornecedor_id INTEGER REFERENCES fornecedor(id),
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);  
CREATE TABLE saida (
    id SERIAL PRIMARY KEY,
    produto_id INTEGER REFERENCES produto(id),
    cliente_id INTEGER REFERENCES cliente(id),
    quantidade INTEGER NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    nome_completo VARCHAR(100),
    perfil VARCHAR(20) DEFAULT 'estoquista',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO usuarios (usuario, senha, nome_completo, perfil)
VALUES ('admin', '123456', 'Administrador do Sistema', 'admin')
ON CONFLICT (usuario) DO NOTHING;

INSERT INTO usuarios (usuario, senha, nome_completo, perfil)
VALUES ('Lua', 'melcher', 'Administrador do Sistema', 'admin')
ON CONFLICT (usuario) DO NOTHING;