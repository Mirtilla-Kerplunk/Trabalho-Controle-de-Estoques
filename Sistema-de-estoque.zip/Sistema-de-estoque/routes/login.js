const express = require('express');
const router = express.Router();
const db = require('../db/connect');
const bcrypt = require('bcryptjs');

// Login
router.post('/', async (req, res) => {
    try {
        const { email, senha } = req.body;

        if (!email || !senha) {
            return res.status(400).send('Nome de usuário e senha são obrigatórios.');
        }

        // Buscar usuário pelo nome (campo `nome` no DB)
        const result = await db.query('SELECT * FROM login WHERE nome = $1', [email]);

        if (result.rows.length === 0) {
            return res.status(401).send('Usuário ou senha inválidos.');
        }

        const user = result.rows[0];

        // Comparar senha com hash
        const valid = await bcrypt.compare(senha, user.senha);
        if (!valid) {
            return res.status(401).send('Usuário ou senha inválidos.');
        }

        return res.redirect('/estoque');
    } catch (error) {
        console.error('POST /login error:', error);
        return res.status(500).send('Erro interno do servidor.');
    }
});

// Registrar conta
router.post('/register', async (req, res) => {
    try {
        const { nome, email, senha, confirmarSenha } = req.body;

        if (!nome || !email || !senha || !confirmarSenha) {
            return res.status(400).send('Todos os campos de cadastro são obrigatórios.');
        }

        if (senha !== confirmarSenha) {
            return res.status(400).send('As senhas não conferem.');
        }

        const existing = await db.query('SELECT * FROM login WHERE nome = $1', [nome]);
        if (existing.rows.length > 0) {
            return res.status(409).send('Usuário já cadastrado.');
        }

        // Hash da senha antes de salvar
        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(senha, salt);

        await db.query(
            'INSERT INTO login (nome, senha) VALUES ($1, $2)',
            [nome, hash]
        );

        return res.redirect('/estoque?tab=movimentacao');
    } catch (error) {
        console.error('POST /register error:', error);
        return res.status(500).send('Erro interno do servidor.');
    }
});

// Validar token (opcional)
router.get('/validar', (req, res) => {
    return res.status(200).json({ mensagem: 'Validação de token não implementada.' });
});

module.exports = router;