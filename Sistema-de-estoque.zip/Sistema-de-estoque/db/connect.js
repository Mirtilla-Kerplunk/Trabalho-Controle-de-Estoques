/**
 * Conexão com PostgreSQL usando o pacote `pg`.
 * Configurações via variáveis de ambiente (DATABASE_URL ou PGHOST/PGUSER/...)
 */

const { Pool } = require('pg');
require('dotenv').config();

// Cria pool usando DATABASE_URL se disponível, caso contrário usa variáveis individuais
const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    host: process.env.PGHOST,
    user: process.env.PGUSER,
    password: process.env.PGPASSWORD,
    database: process.env.PGDATABASE,
    port: process.env.PGPORT ? parseInt(process.env.PGPORT, 10) : undefined,
});

pool.on('connect', () => {
    console.log('✅ Conectado ao banco PostgreSQL');
});

pool.on('error', (err) => {
    console.error('Erro no pool PostgreSQL:', err);
});

// Exporta um wrapper compatível: db.query(text, params) retornando o resultado do pg
module.exports = {
    query: (text, params) => pool.query(text, params),
    pool
};