-- Criação da tabela produto
CREATE TABLE produto (
    id serial PRIMARY KEY,
    nome varchar(100),
    marca varchar(100),
    preco decimal(8,2),
    peso decimal(8,2),
    ALTER TABLE produto
    ADD COLUMN quantidade INTEGER DEFAULT 0;
);
CREATE TABLE cliente (
    id serial PRIMARY KEY,
    nome varchar(100),
    email varchar(100),
    telefone varchar(11),
    endereco varchar(255),
    cidade varchar(100),
    uf varchar(2)
);
CREATE TABLE fornecedor (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefone VARCHAR(11),
    endereco VARCHAR(255),
    cidade VARCHAR(100),
    uf VARCHAR(2)
);
CREATE TABLE login (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    senha VARCHAR(100) NOT NULL
);
CREATE TABLE entrada (
    id SERIAL PRIMARY KEY,
    produto_id INTEGER REFERENCES produto(id),
    quantidade INTEGER NOT NULL,
    Fornecedor_id INTEGER REFERENCES fornecedor(id),
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);  
CREATE TABLE saida (
    id SERIAL PRIMARY KEY,
    produto_id INTEGER REFERENCES produto(id),
    cliente_id INTEGER REFERENCES cliente(id),
    quantidade INTEGER NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);