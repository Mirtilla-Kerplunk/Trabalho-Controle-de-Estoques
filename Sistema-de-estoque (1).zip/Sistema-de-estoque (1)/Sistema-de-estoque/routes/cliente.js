//importar os módulos
//express
const express = require('express');
//Criar um roteador do express para definir as rotas separadamente
//do app principal
const routes = express.Router();
//importar a conexão com o banco de dados PostgreSQL
const db = require('../db/connect');

//--------------------------------------------------------------------
//ROTA GET
routes.get('/', async (req, res) => {
    //Realizar a consulta no banco de dados usando SQL.
    const result = await db.query('SELECT * FROM cliente');

    //Responde com os dados da consulta
    res.status(200).json(result.rows);
});

//------------------------------------------------------------------
//ROTA POST
routes.post('/', async (req, res) => {
//Extrair os valores recebidos por parâmetros
 const {nome, email, telefone, endereco, cidade, uf} = req.body;

 if(!nome || !email || !telefone || !endereco || !cidade || !uf){
    return res.status(400).json({mensagem: 'Todos os campos são obrigatórios.'});
 }

 //Constrói a query inserção SQL
 const sql = `
    INSERT INTO cliente (nome, email, telefone, endereco, cidade,uf)
    VALUES ($1, $2, $3, $4, $5, $6)
    RETURNING *
 `;

 //Valores qeu serão usado na inserção SQL
 const valores = [nome, email, telefone, endereco, cidade,uf];

 //Executa a operação no banco de dados
 const result = await db.query(sql, valores);

 //Retorna para o cliente os valores inseridos no banco
 res.status(201).json(result.rows[0]);
});

//--------------------------------------------------------------------
//Rota PUT

routes.put('/:id', async (req, res) => {
    //Obtém o id informado pelo usuário na URL
    const {id} = req.params;

    //Verifica se o id foi informado
    if(!id){
        return res.status(400).json({mensagem: 'id do cliente é obrigatório'});
    }

    //Extrair as informações do corpo da requisição
    const {nome, email, telefone, endereco, cidade, uf} = req.body;

    //Verifica se todos os campos estãos preenchidos
    if(!nome || !email || !telefone || !endereco || !cidade || !uf ){
        return res.status(400).json({mensagem: 'Todos os campos são Obrigatórios.'});
    }

    //criação da query SQL de alteração no banco de dados
    const sql = `
    UPDATE cliente
    SET nome = $1 , email = $2 , telefone = $3 , 
    endereco = $4 , cidade = $5 , uf = $6
    WHERE id = $7
    RETURNING *
    `;

    //valores usado na query
    const valores = [nome, email, telefone, endereco, cidade, uf, id];

    //Executa a atualização no banco de dados
    const result = await db.query(sql, valores);

    //Caso não tenha o id informado no banco
    //informa que o cliente não foi encontrado
    if(result.rows.length === 0){
        return res.status(404).json({mensagem: 'Cliente não encontrado.'});
    }

    res.status(200).json(result.rows[0]);
});

//--------------------------------------------------------------------------
//ROTA DELETE
routes.delete('/:id', async (req, res) => {
//obtém o id informado pelo usuário
const {id} = req.params;

//Verifica se id existe
if(!id){
    return res.status(400).json({mensagem: 'O id do cliente é obrigatório'});
}

//Constrói a query SQL
const sql = `
DELETE FROM cliente
WHERE id = $1
RETURNING *
`;

//valores que serão usados na query
const valores = [id];

//Apagar os dados no banco de dados
const result = await db.query(sql, valores);

//Verifica se o id existe
//ou se ele já não foi deletado
if(result.rows.length === 0) {
    return res.status(404).json({mensagem: 'cliente não encontrado.'});
}

//Quando a requisação for realizada
res.status(200).json({mensagem: `Cliente com ID ${id} foi excluído com sucesso.`});
});

module.exports = routes;